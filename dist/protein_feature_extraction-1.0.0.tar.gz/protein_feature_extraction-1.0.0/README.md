# Protein Feature Extraction Package

A comprehensive Python package for extracting multiple types of features from protein sequences in FASTA format. This package combines 9 different feature extraction methods and produces a single unified CSV file with all features.

## Features Extracted

The package extracts **9 different types of protein features**:

1. **Amino Acid Composition (AAC)** - G1 (20 features)
   - Normalized frequency of each amino acid
   
2. **Dipeptide Composition (DCP)** - G2 (400 features)
   - Normalized frequency of dipeptide pairs
   
3. **Physicochemical Properties (PCP)** - G3 (42 features)
   - 21 physicochemical properties + 21 transition properties
   
4. **Conjoint Triad Composition (CTriad)** - G4 (343 features)
   - 7×7×7 triad matrix flattened
   
5. **Entropy Features** - G6 (10 features)
   - Shannon entropy calculated over 10 sequence segments
   
6. **Protein Parameters** - G7 (7 features)
   - Molecular weight, aromaticity, instability index, GRAVY, isoelectric point, molar extinction coefficients
   
7. **Quasi-Sequence Order (QSO)** - G8 (50 features)
   - Sequence-order coupling numbers with weights
   
8. **Word2Vec Features** - G5 (100 features)
   - Word2Vec embeddings based on 3-grams
   
9. **ESM Embeddings** - G9 (1280 features)
   - Pre-trained ESM language model embeddings from layer 33

## Installation

### Requirements

- Python 3.7+
- pandas
- numpy
- Biopython
- scipy
- gensim
- torch (for ESM embeddings)
- fair-esm (for ESM embeddings)

### Setup

```bash
# Install dependencies
pip install pandas numpy biopython scipy gensim torch fair-esm
```

## Usage

### Quick Test

**New to the package?** Try the included example file:

```bash
python -m protein_feature_extraction.unified_extractor example_proteins.fasta example_output.csv
```

This runs on 5 example proteins and completes in about **1-2 minutes**.

### Basic Usage

```python
from protein_feature_extraction import extract_all_features

# Extract all features from a FASTA file
features_df = extract_all_features("proteins.fasta", "output_features.csv")

# Print information about extracted features
print(f"Sequences: {features_df.shape[0]}")
print(f"Total features: {features_df.shape[1]}")
```

### Advanced Usage

```python
from protein_feature_extraction import extract_all_features

features_df = extract_all_features(
    fasta_file="proteins.fasta",
    output_file="all_features.csv",
    word2vec_model_path="/path/to/word2vec_model.txt",
    esm_model_name="esm2_t33_650M_UR50D",
    esm_tokens_per_batch=4096,
    esm_seq_length=1022,
    esm_repr_layers=[33],
    verbose=True
)
```

### Command Line Usage

```bash
python -m protein_feature_extraction.unified_extractor proteins.fasta output_features.csv
```

## Parameters

### Main Function: `extract_all_features()`

- **fasta_file** (str): Path to input FASTA file containing protein sequences
- **output_file** (str): Path to save the combined features CSV (default: "all_features.csv")
- **word2vec_model_path** (str, optional): Path to Word2Vec model file
- **esm_model_name** (str): ESM model name (default: "esm2_t33_650M_UR50D")
- **esm_output_dir** (str, optional): Directory to save ESM embeddings
- **esm_tokens_per_batch** (int): Tokens per batch for ESM (default: 4096)
- **esm_seq_length** (int): Maximum sequence length (default: 1022)
- **esm_repr_layers** (list): ESM representation layers to extract (default: [33])
- **temp_dir** (str, optional): Temporary directory for intermediate files
- **verbose** (bool): Print progress messages (default: True)

## Output

The output CSV file contains:
- **Index**: Protein sequence IDs from the FASTA file
- **Columns**: Combined features from all 9 extraction methods, with prefixes:
  - `G1_*`: Amino Acid Composition
  - `G2_*`: Dipeptide Composition
  - `G3_*`: Physicochemical Properties
  - `G4_*`: Conjoint Triad Composition
  - `G5_*`: Word2Vec Features
  - `G6_*`: Entropy Features
  - `G7_*`: Protein Parameters
  - `G8_*`: QSO Features
  - `G9_*`: ESM Embeddings

## Examples

### Example 1: Basic Feature Extraction

```python
from protein_feature_extraction import extract_all_features

# Extract features from proteins.fasta
df = extract_all_features("proteins.fasta", "features.csv")
print(df.head())
```

### Example 2: Machine Learning Pipeline

```python
from protein_feature_extraction import extract_all_features
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier

# Extract features
X = extract_all_features("proteins.fasta").values

# Standardize features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Train classifier
clf = RandomForestClassifier()
clf.fit(X_scaled, y)
```

## Performance Notes

- **Execution time** depends on the number of sequences and feature types:
  - Basic features (AAC, DCP, PCP, CTriad, Entropy, ProtParams, QSO): ~seconds per 100 sequences
  - Word2Vec: ~seconds per 100 sequences (depends on sequence length)
  - ESM embeddings: ~1-2 minutes per 10-20 sequences (GPU recommended for faster processing)

- **Example runtimes**:
  - 5 proteins: ~1-2 minutes
  - 270 proteins: ~10-15 minutes (CPU), ~5-10 minutes (GPU)
  - 1000+ proteins: 1+ hours (CPU), 30+ minutes (GPU)

- **Memory usage**: Approximately 1-2 MB per sequence for basic features, more for ESM embeddings

## Citation

If you use this package in your research, please cite the original feature extraction methods:

- Amino Acid Composition: Chou, K. C. (1995)
- Physicochemical Properties: Karchin, R. et al. (2006)
- Conjoint Triad: Mishra, S. et al. (2010)
- Quasi-Sequence Order: Chou, K. C. (1997)
- Word2Vec: Mikolov, T. et al. (2013)
- ESM: Rives, A. et al. (2021)

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Troubleshooting

### Issue: "Global outname variable not found"
**Solution**: The package sets this automatically; no action needed.

### Issue: Word2Vec extraction fails
**Solution**: Provide the correct model path via `word2vec_model_path` parameter, or ensure the default model exists at the expected location.

### Issue: ESM extraction fails
**Solution**: Ensure `fair-esm` and `torch` are installed correctly. Run `pip install torch fair-esm`. Check that you have sufficient GPU memory or CPU resources available.

### Issue: Out of memory with ESM
**Solution**: Use a smaller ESM model, reduce `esm_tokens_per_batch`, or increase available memory.

## Support

For issues, questions, or contributions, please contact the development team or visit the project repository.

## Changelog

### Version 1.0.0
- Initial release
- Support for 9 feature extraction methods
- CLI and Python API interfaces
- ESM embeddings as core feature
- Comprehensive error handling
